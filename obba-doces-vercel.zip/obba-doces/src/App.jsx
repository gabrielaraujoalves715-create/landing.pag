import Navbar from "./sections/Navbar";
import Hero from "./sections/Hero";
import BentoGrid from "./sections/BentoGrid";
import WhyObba from "./sections/WhyObba";
import Testimonials from "./sections/Testimonials";
import CTA from "./sections/CTA";
import Footer from "./sections/Footer";

export default function App() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <BentoGrid />
        <WhyObba />
        <Testimonials />
        <CTA />
      </main>
      <Footer />
    </>
  );
}
