import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import AnimatedSection from "../components/AnimatedSection";
import { useScrollAnimation } from "../hooks/useScrollAnimation";
import { fadeUp, stagger } from "../animations";
import { bentoCards } from "../constants";

export default function BentoGrid() {
  const { ref, isInView } = useScrollAnimation();
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 768);
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, []);

  return (
    <section
      id="cardapio"
      aria-label="Cardápio"
      className="py-24 px-6"
      style={{ background: "#FFF5E6" }}
    >
      <div className="max-w-5xl mx-auto">
        <AnimatedSection className="text-center mb-16">
          <motion.p
            variants={fadeUp}
            className="text-sm font-bold uppercase tracking-widest mb-3"
            style={{ color: "#4ECDC4" }}
          >
            Nosso Cardápio
          </motion.p>
          <motion.h2
            variants={fadeUp}
            className="text-4xl md:text-5xl font-black leading-tight"
            style={{ fontFamily: "'Playfair Display', Georgia, serif", color: "#3D1A0A" }}
          >
            Feito para encantar
          </motion.h2>
          <motion.p
            variants={fadeUp}
            className="mt-4 text-base max-w-lg mx-auto"
            style={{ color: "#8B5E3C" }}
          >
            Cada produto é preparado com ingredientes selecionados e muito amor,
            pensado para fazer seu momento ainda mais especial.
          </motion.p>
        </AnimatedSection>

        <motion.div
          ref={ref}
          style={{
            display: "grid",
            gridTemplateColumns: isMobile ? "1fr" : "repeat(3, 1fr)",
            gap: "1rem",
          }}
          variants={stagger}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {bentoCards.map((card, i) => (
            <motion.div
              key={i}
              variants={fadeUp}
              whileHover={{ scale: 1.02, y: -4 }}
              transition={{ type: "spring", stiffness: 300, damping: 25 }}
              className="rounded-3xl p-7 cursor-pointer relative overflow-hidden shadow-lg"
              style={{
                background: card.bg,
                minHeight: 200,
                gridColumn: isMobile ? "1 / -1" : card.wide ? "span 2" : "span 1",
              }}
            >
              <div
                className="absolute -top-8 -right-8 w-32 h-32 rounded-full opacity-20"
                style={{ background: card.light ? "white" : "#E8537A" }}
                aria-hidden="true"
              />
              <div className="text-4xl mb-4" aria-hidden="true">{card.emoji}</div>
              <h3
                className="text-xl font-black mb-2"
                style={{
                  color: card.light ? "white" : "#3D1A0A",
                  fontFamily: "'Playfair Display', Georgia, serif",
                }}
              >
                {card.title}
              </h3>
              <p
                className="text-sm leading-relaxed"
                style={{ color: card.light ? "rgba(255,255,255,0.85)" : "#5C2D0E" }}
              >
                {card.desc}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
