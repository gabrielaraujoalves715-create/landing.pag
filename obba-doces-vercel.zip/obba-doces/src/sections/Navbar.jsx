import { useState, useEffect } from "react";
import { motion, useScroll } from "framer-motion";
import { WHATSAPP_URL } from "../constants";

export default function Navbar() {
  const { scrollY } = useScroll();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const unsub = scrollY.on("change", (v) => setScrolled(v > 60));
    return unsub;
  }, [scrollY]);

  return (
    <motion.nav
      role="navigation"
      aria-label="Menu principal"
      className="fixed top-0 left-0 right-0 z-50 px-6 py-4 flex items-center justify-between"
      style={{
        background: scrolled ? "rgba(255,245,230,0.92)" : "transparent",
        backdropFilter: scrolled ? "blur(16px)" : "none",
        WebkitBackdropFilter: scrolled ? "blur(16px)" : "none",
        borderBottom: scrolled ? "1px solid rgba(232,83,122,0.12)" : "none",
        transition: "background 0.4s, border-bottom 0.4s",
      }}
      initial={{ y: -60, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
    >
      <div
        className="text-xl font-black"
        style={{
          fontFamily: "'Playfair Display', Georgia, serif",
          color: scrolled ? "#E8537A" : "#3D1A0A",
          transition: "color 0.4s",
        }}
      >
        Obba Doces 🍬
      </div>

      <a
        href={WHATSAPP_URL}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Fazer pedido pelo WhatsApp"
        className="px-5 py-2 rounded-full text-sm font-bold text-white shadow-md transition-transform hover:scale-105 active:scale-95"
        style={{ background: "linear-gradient(135deg, #E8537A, #C0405E)" }}
      >
        Pedir Agora
      </a>
    </motion.nav>
  );
}
