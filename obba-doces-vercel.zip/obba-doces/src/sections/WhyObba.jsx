import { motion } from "framer-motion";
import AnimatedSection from "../components/AnimatedSection";
import { fadeUp } from "../animations";
import { features } from "../constants";

export default function WhyObba() {
  return (
    <section
      aria-label="Por que escolher a Obba Doces"
      className="py-24 px-6 relative overflow-hidden"
      style={{ background: "linear-gradient(135deg, #3D1A0A 0%, #5C2D0E 100%)" }}
    >
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: "radial-gradient(circle, #4ECDC4 1px, transparent 1px)",
          backgroundSize: "32px 32px",
        }}
        aria-hidden="true"
      />

      <div className="max-w-5xl mx-auto relative z-10">
        <AnimatedSection className="text-center mb-16">
          <motion.p
            variants={fadeUp}
            className="text-sm font-bold uppercase tracking-widest mb-3"
            style={{ color: "#4ECDC4" }}
          >
            Por que escolher a Obba Doces?
          </motion.p>
          <motion.h2
            variants={fadeUp}
            className="text-4xl md:text-5xl font-black leading-tight text-white"
            style={{ fontFamily: "'Playfair Display', Georgia, serif" }}
          >
            Mais que doce,{" "}
            <span style={{ color: "#E8537A" }}>é uma experiência</span>
          </motion.h2>
        </AnimatedSection>

        <AnimatedSection className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {features.map((f, i) => (
            <motion.div
              key={i}
              variants={fadeUp}
              whileHover={{ scale: 1.03 }}
              className="rounded-2xl p-7 relative overflow-hidden"
              style={{
                background: "rgba(255,255,255,0.05)",
                border: "1px solid rgba(255,255,255,0.1)",
                backdropFilter: "blur(10px)",
                WebkitBackdropFilter: "blur(10px)",
              }}
            >
              <div className="text-4xl mb-4" aria-hidden="true">{f.icon}</div>
              <h3
                className="text-lg font-bold text-white mb-2"
                style={{ fontFamily: "'Playfair Display', Georgia, serif" }}
              >
                {f.title}
              </h3>
              <p className="text-sm leading-relaxed" style={{ color: "rgba(255,255,255,0.65)" }}>
                {f.desc}
              </p>
              <div
                className="absolute -bottom-4 -right-4 w-20 h-20 rounded-full opacity-10"
                style={{ background: "#E8537A" }}
                aria-hidden="true"
              />
            </motion.div>
          ))}
        </AnimatedSection>
      </div>
    </section>
  );
}
