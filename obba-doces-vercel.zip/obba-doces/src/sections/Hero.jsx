import { motion, useScroll, useTransform } from "framer-motion";
import FloatingOrb from "../components/FloatingOrb";
import WhatsAppIcon from "../components/WhatsAppIcon";
import { WHATSAPP_URL } from "../constants";

export default function Hero() {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 500], [0, 120]);
  const opacity = useTransform(scrollY, [0, 400], [1, 0]);

  return (
    <section
      aria-label="Apresentação"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(135deg, #FFF5E6 0%, #FDECD5 30%, #FFF0F5 60%, #E8F8F7 100%)",
        }}
      />

      {/* Orbs decorativos */}
      <FloatingOrb
        style={{ width: 500, height: 500, top: -100, right: -150, background: "rgba(232,83,122,0.12)" }}
      />
      <FloatingOrb
        style={{ width: 400, height: 400, bottom: -80, left: -120, background: "rgba(78,205,196,0.14)" }}
      />
      <FloatingOrb
        style={{ width: 300, height: 300, top: "40%", left: "30%", background: "rgba(212,168,71,0.08)" }}
      />

      {/* Textura de pontos */}
      <div
        className="absolute inset-0 opacity-30"
        style={{
          backgroundImage: "radial-gradient(circle, #E8537A 1px, transparent 1px)",
          backgroundSize: "40px 40px",
        }}
      />

      {/* Círculos decorativos */}
      <motion.div
        className="absolute top-20 left-10 w-16 h-16 rounded-full border-4 border-rose-300 opacity-40"
        animate={{ rotate: 360 }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        aria-hidden="true"
      />
      <motion.div
        className="absolute bottom-32 right-16 w-10 h-10 rounded-full border-4 border-teal-300 opacity-40"
        animate={{ rotate: -360 }}
        transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
        aria-hidden="true"
      />
      <motion.div
        className="absolute top-1/3 right-20 w-6 h-6 rounded-full opacity-60"
        style={{ background: "#D4A847" }}
        animate={{ y: [-10, 10, -10] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        aria-hidden="true"
      />

      {/* Conteúdo principal */}
      <motion.div
        style={{ y, opacity }}
        className="relative z-10 text-center px-6 max-w-4xl mx-auto"
      >
        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="inline-flex items-center gap-2 px-5 py-2 rounded-full text-sm font-semibold mb-8 shadow-md"
          style={{
            background: "rgba(232,83,122,0.1)",
            color: "#C0405E",
            border: "1.5px solid rgba(232,83,122,0.3)",
          }}
        >
          <span aria-hidden="true">🍬</span> Feito com amor, desde o coração
        </motion.div>

        {/* Título */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        >
          <h1
            className="font-black leading-none mb-2"
            style={{
              fontFamily: "'Playfair Display', Georgia, serif",
              fontSize: "clamp(4rem, 12vw, 9rem)",
              background: "linear-gradient(135deg, #E8537A 0%, #C0405E 40%, #4ECDC4 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
              letterSpacing: "-2px",
            }}
          >
            Obba
          </h1>
          <h2
            className="font-black leading-none"
            style={{
              fontFamily: "'Playfair Display', Georgia, serif",
              fontSize: "clamp(2rem, 6vw, 4.5rem)",
              color: "#3D1A0A",
              letterSpacing: "0.3em",
              textTransform: "uppercase",
            }}
          >
            Doces
          </h2>
        </motion.div>

        {/* Ornamento divisor */}
        <motion.div
          initial={{ scaleX: 0, opacity: 0 }}
          animate={{ scaleX: 1, opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.8 }}
          className="flex items-center justify-center gap-3 my-6"
          aria-hidden="true"
        >
          <div className="h-px w-20 bg-gradient-to-r from-transparent to-rose-400" />
          <span style={{ color: "#D4A847", fontSize: "1.5rem" }}>✦</span>
          <div className="h-px w-20 bg-gradient-to-l from-transparent to-rose-400" />
        </motion.div>

        {/* Tagline */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.75, duration: 0.7 }}
          className="text-lg md:text-xl max-w-xl mx-auto leading-relaxed mb-10"
          style={{ color: "#5C2D0E", fontStyle: "italic" }}
        >
          Bolos decorados, docinhos artesanais e sobremesas especiais —
          cada pedaço carregado de carinho e sabor.
        </motion.p>

        {/* Botões CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9, duration: 0.7 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Fazer encomenda pelo WhatsApp"
            className="group relative px-8 py-4 rounded-full font-bold text-white text-base shadow-2xl overflow-hidden transition-transform hover:scale-105 active:scale-95"
            style={{ background: "linear-gradient(135deg, #E8537A 0%, #C0405E 100%)" }}
          >
            <span className="relative z-10 flex items-center gap-2">
              <WhatsAppIcon size={20} color="currentColor" />
              Fazer Encomenda
            </span>
          </a>

          <a
            href="#cardapio"
            className="px-8 py-4 rounded-full font-semibold text-base border-2 transition-all hover:scale-105 active:scale-95"
            style={{
              borderColor: "#4ECDC4",
              color: "#2A9D96",
              background: "rgba(78,205,196,0.08)",
            }}
          >
            Ver Cardápio ↓
          </a>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.1, duration: 0.7 }}
          className="mt-16 flex items-center justify-center gap-8 flex-wrap"
        >
          {[
            { value: "433+", label: "Clientes felizes" },
            { value: "100%", label: "Feito com amor" },
            { value: "5★", label: "Avaliação" },
          ].map((stat, i) => (
            <div key={i} className="text-center">
              <div
                className="text-2xl font-black"
                style={{
                  color: i === 1 ? "#4ECDC4" : "#E8537A",
                  fontFamily: "'Playfair Display', Georgia, serif",
                }}
              >
                {stat.value}
              </div>
              <div className="text-xs font-medium mt-0.5" style={{ color: "#8B5E3C" }}>
                {stat.label}
              </div>
            </div>
          ))}
        </motion.div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1, y: [0, 10, 0] }}
        aria-hidden="true"
      >
        <div
          className="w-6 h-10 rounded-full border-2 flex items-start justify-center p-1.5"
          style={{ borderColor: "rgba(232,83,122,0.4)" }}
        >
          <div className="w-1.5 h-3 rounded-full" style={{ background: "#E8537A" }} />
        </div>
      </motion.div>
    </section>
  );
}
