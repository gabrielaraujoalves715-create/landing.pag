import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import AnimatedSection from "../components/AnimatedSection";
import FloatingOrb from "../components/FloatingOrb";
import StarRating from "../components/StarRating";
import { fadeUp } from "../animations";
import { testimonials } from "../constants";

export default function Testimonials() {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const id = setInterval(
      () => setActive((prev) => (prev + 1) % testimonials.length),
      4000
    );
    return () => clearInterval(id);
  }, []);

  return (
    <section
      aria-label="Depoimentos de clientes"
      className="py-24 px-6 relative overflow-hidden"
      style={{ background: "#FFF5E6" }}
    >
      <FloatingOrb
        style={{ width: 350, height: 350, top: -100, left: -100, background: "rgba(78,205,196,0.1)" }}
      />
      <FloatingOrb
        style={{ width: 300, height: 300, bottom: -80, right: -60, background: "rgba(232,83,122,0.1)" }}
      />

      <div className="max-w-4xl mx-auto relative z-10">
        <AnimatedSection className="text-center mb-16">
          <motion.p
            variants={fadeUp}
            className="text-sm font-bold uppercase tracking-widest mb-3"
            style={{ color: "#E8537A" }}
          >
            Depoimentos
          </motion.p>
          <motion.h2
            variants={fadeUp}
            className="text-4xl md:text-5xl font-black"
            style={{ fontFamily: "'Playfair Display', Georgia, serif", color: "#3D1A0A" }}
          >
            O que nossos clientes dizem
          </motion.h2>
        </AnimatedSection>

        {/* Card principal */}
        <div className="relative mb-8" style={{ minHeight: 260 }}>
          <AnimatePresence mode="wait">
            <motion.div
              key={active}
              initial={{ opacity: 0, y: 30, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.97 }}
              transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
              className="rounded-3xl p-8 shadow-2xl flex flex-col justify-between"
              style={{
                background: "white",
                border: `2px solid ${testimonials[active].color}30`,
                minHeight: 260,
              }}
            >
              <div>
                <StarRating count={testimonials[active].stars} />
                <p
                  className="mt-4 text-base md:text-lg leading-relaxed"
                  style={{ color: "#3D1A0A", fontStyle: "italic" }}
                >
                  "{testimonials[active].text}"
                </p>
              </div>
              <div className="flex items-center gap-3 mt-6">
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center text-white text-sm font-black flex-shrink-0"
                  style={{ background: testimonials[active].color }}
                  aria-hidden="true"
                >
                  {testimonials[active].avatar}
                </div>
                <div>
                  <div className="font-bold text-sm" style={{ color: "#3D1A0A" }}>
                    {testimonials[active].name}
                  </div>
                  <div className="text-xs" style={{ color: "#8B5E3C" }}>
                    {testimonials[active].handle}
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Dots de navegação */}
        <div className="flex justify-center gap-2 mb-10" role="tablist" aria-label="Navegar entre depoimentos">
          {testimonials.map((_, i) => (
            <button
              key={i}
              onClick={() => setActive(i)}
              role="tab"
              aria-selected={i === active}
              aria-label={`Depoimento ${i + 1}`}
              className="rounded-full transition-all duration-300"
              style={{
                width: i === active ? 28 : 8,
                height: 8,
                background: i === active ? "#E8537A" : "rgba(232,83,122,0.3)",
                border: "none",
                cursor: "pointer",
                padding: 0,
              }}
            />
          ))}
        </div>

        {/* Mini cards (desktop) */}
        <div className="hidden md:grid grid-cols-2 gap-4">
          {testimonials
            .filter((_, i) => i !== active)
            .slice(0, 2)
            .map((t) => (
              <motion.div
                key={t.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 0.7, y: 0 }}
                whileHover={{ opacity: 1, scale: 1.02 }}
                onClick={() => setActive(testimonials.indexOf(t))}
                className="rounded-2xl p-5 cursor-pointer"
                style={{
                  background: "white",
                  border: "1px solid rgba(232,83,122,0.15)",
                }}
              >
                <StarRating count={t.stars} />
                <p
                  className="mt-2 text-sm line-clamp-2"
                  style={{ color: "#5C2D0E", fontStyle: "italic" }}
                >
                  "{t.text}"
                </p>
                <p className="mt-2 text-xs font-bold" style={{ color: t.color }}>
                  {t.name}
                </p>
              </motion.div>
            ))}
        </div>
      </div>
    </section>
  );
}
