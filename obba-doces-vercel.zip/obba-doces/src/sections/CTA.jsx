import { motion } from "framer-motion";
import WhatsAppIcon from "../components/WhatsAppIcon";
import { useScrollAnimation } from "../hooks/useScrollAnimation";
import { WHATSAPP_URL } from "../constants";

export default function CTA() {
  const { ref, isInView } = useScrollAnimation();

  return (
    <section
      aria-label="Chamada para ação"
      className="py-24 px-6 relative overflow-hidden"
      style={{ background: "#FFF5E6" }}
    >
      <motion.div
        ref={ref}
        initial={{ opacity: 0, scale: 0.95 }}
        animate={isInView ? { opacity: 1, scale: 1 } : {}}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="max-w-3xl mx-auto rounded-3xl overflow-hidden shadow-2xl relative"
        style={{
          background: "linear-gradient(135deg, #E8537A 0%, #C0405E 50%, #4ECDC4 100%)",
        }}
      >
        {/* Decorações internas */}
        <div className="absolute inset-0" aria-hidden="true">
          <div
            className="absolute top-0 right-0 w-72 h-72 rounded-full opacity-20 -translate-y-1/2 translate-x-1/2"
            style={{ background: "white" }}
          />
          <div
            className="absolute bottom-0 left-0 w-48 h-48 rounded-full opacity-15 translate-y-1/2 -translate-x-1/2"
            style={{ background: "#D4A847" }}
          />
          <div
            className="absolute inset-0 opacity-10"
            style={{
              backgroundImage: "radial-gradient(circle, white 1px, transparent 1px)",
              backgroundSize: "24px 24px",
            }}
          />
        </div>

        <div className="relative z-10 text-center py-16 px-8">
          <motion.div
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            className="text-6xl mb-6"
            aria-hidden="true"
          >
            🎂
          </motion.div>

          <h2
            className="text-3xl md:text-5xl font-black text-white mb-4 leading-tight"
            style={{ fontFamily: "'Playfair Display', Georgia, serif" }}
          >
            Pronta para encantar
            <br />
            seu momento especial?
          </h2>

          <p className="text-white/80 text-base max-w-md mx-auto mb-10 leading-relaxed">
            Entre em contato pelo WhatsApp e faça sua encomenda! Atendimento
            rápido, personalizado e com muito carinho. 🍬
          </p>

          <motion.a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Fazer minha encomenda pelo WhatsApp"
            whileHover={{ scale: 1.07 }}
            whileTap={{ scale: 0.97 }}
            className="inline-flex items-center gap-3 px-10 py-4 rounded-full font-black text-lg shadow-2xl"
            style={{ background: "white", color: "#E8537A" }}
          >
            <WhatsAppIcon size={24} color="#25D366" />
            Fazer Minha Encomenda
          </motion.a>

          <p className="text-white/60 text-sm mt-5">
            Encomendas apenas pelo WhatsApp • Atendimento personalizado
          </p>
        </div>
      </motion.div>
    </section>
  );
}
