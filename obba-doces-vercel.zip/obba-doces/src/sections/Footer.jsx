import { WHATSAPP_URL, INSTAGRAM_URL, THREADS_URL } from "../constants";

export default function Footer() {
  return (
    <footer className="py-10 px-6 text-center" style={{ background: "#3D1A0A" }}>
      <div
        className="text-2xl font-black mb-2"
        style={{ fontFamily: "'Playfair Display', Georgia, serif", color: "#E8537A" }}
      >
        Obba Doces
      </div>
      <p className="text-sm mb-4" style={{ color: "rgba(255,255,255,0.5)" }}>
        Feito com amor ♡
      </p>
      <nav
        aria-label="Links de contato"
        className="flex items-center justify-center gap-6 text-xs"
        style={{ color: "rgba(255,255,255,0.35)" }}
      >
        <a
          href={WHATSAPP_URL}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="WhatsApp da Obba Doces"
          className="hover:text-white transition-colors"
        >
          WhatsApp
        </a>
        <span aria-hidden="true">•</span>
        <a
          href={INSTAGRAM_URL}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Instagram da Obba Doces"
          className="hover:text-white transition-colors"
        >
          Instagram
        </a>
        <span aria-hidden="true">•</span>
        <a
          href={THREADS_URL}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Threads da Obba Doces"
          className="hover:text-white transition-colors"
        >
          Threads
        </a>
      </nav>
      <p className="text-xs mt-6" style={{ color: "rgba(255,255,255,0.2)" }}>
        © {new Date().getFullYear()} Obba Doces. Todos os direitos reservados.
      </p>
    </footer>
  );
}
