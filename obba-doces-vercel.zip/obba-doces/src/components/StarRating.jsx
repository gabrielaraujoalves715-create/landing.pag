export default function StarRating({ count }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: count }).map((_, i) => (
        <span key={i} style={{ color: "#D4A847" }} className="text-sm">
          ★
        </span>
      ))}
    </div>
  );
}
