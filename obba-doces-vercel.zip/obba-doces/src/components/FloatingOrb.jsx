import { motion } from "framer-motion";

export default function FloatingOrb({ style }) {
  return (
    <motion.div
      className="absolute rounded-full blur-3xl pointer-events-none"
      animate={{ y: [0, -20, 0], scale: [1, 1.05, 1] }}
      transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
      style={style}
    />
  );
}
