export const WHATSAPP_URL = "https://wa.me/5511946408023";

export const INSTAGRAM_URL = "https://www.instagram.com/obba_docess";

export const THREADS_URL = "https://www.threads.net/@obba_docess";

export const testimonials = [
  {
    name: "Tatiane M.",
    handle: "@ttamy__",
    text: "O bolo do aniversário da minha filha ficou LINDO e delicioso! Todo mundo perguntou onde comprei. 🎂❤️",
    stars: 5,
    avatar: "TM",
    color: "#E8537A",
  },
  {
    name: "Paula C.",
    handle: "@paulacassandra1",
    text: "Os brigadeiros são os melhores que já comi na vida. Atendimento via WhatsApp super rápido e atencioso!",
    stars: 5,
    avatar: "PC",
    color: "#4ECDC4",
  },
  {
    name: "Renata S.",
    handle: "@renata_s",
    text: "Pedi um kit presente para o meu chefe e ele amou. Apresentação impecável, sabor incrível. Recomendo demais!",
    stars: 5,
    avatar: "RS",
    color: "#D4A847",
  },
  {
    name: "Fernanda L.",
    handle: "@fer_lima",
    text: "A Obba Doces transformou a festa da minha bebê! Tudo com muito amor e capricho. Voltarei sempre! 💕",
    stars: 5,
    avatar: "FL",
    color: "#E8537A",
  },
];

export const bentoCards = [
  {
    wide: true,
    bg: "linear-gradient(135deg, #E8537A 0%, #C0405E 100%)",
    emoji: "🎂",
    title: "Bolos Decorados",
    desc: "Para aniversários, casamentos, chás e qualquer momento que mereça ser celebrado com beleza.",
    light: true,
  },
  {
    wide: false,
    bg: "linear-gradient(135deg, #FFF5E6 0%, #FDECD5 100%)",
    emoji: "🍫",
    title: "Docinhos",
    desc: "Brigadeiros, trufas e beijinhos artesanais.",
    light: false,
  },
  {
    wide: false,
    bg: "linear-gradient(135deg, #4ECDC4 0%, #38B2AC 100%)",
    emoji: "🍮",
    title: "Pudins",
    desc: "Sobremesas que derretem na boca.",
    light: true,
  },
  {
    wide: false,
    bg: "linear-gradient(135deg, #D4A847 0%, #B8860B 100%)",
    emoji: "🥚",
    title: "Páscoa",
    desc: "Ovos artesanais únicos.",
    light: true,
  },
  {
    wide: true,
    bg: "linear-gradient(135deg, #FFF0F5 0%, #FFE0EC 100%)",
    emoji: "🎁",
    title: "Kits Presente",
    desc: "Surpreenda com elegância — montamos kits personalizados para qualquer data especial ou homenagem.",
    light: false,
  },
];

export const features = [
  {
    icon: "💝",
    title: "Feito com Amor",
    desc: "Cada detalhe é pensado com carinho para tornar o seu momento especial.",
  },
  {
    icon: "🌿",
    title: "Ingredientes Selecionados",
    desc: "Usamos apenas ingredientes de qualidade para garantir o melhor sabor.",
  },
  {
    icon: "🎨",
    title: "Personalizado pra Você",
    desc: "Do design ao sabor, personalizamos cada detalhe para transformar sua ideia em sabor.",
  },
  {
    icon: "📱",
    title: "Pedido Fácil",
    desc: "Faça sua encomenda direto pelo WhatsApp, simples e rápido.",
  },
];
