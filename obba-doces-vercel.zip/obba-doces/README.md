# 🍬 Obba Doces — Landing Page

Landing page profissional da Obba Doces, construída com React + Vite + Tailwind CSS + Framer Motion.

## ✨ Tecnologias

- **React 18** — UI
- **Vite 5** — Build e dev server
- **Tailwind CSS 3** — Estilização
- **Framer Motion 11** — Animações

## 🚀 Como rodar localmente

```bash
# 1. Instalar dependências
npm install

# 2. Iniciar servidor de desenvolvimento
npm run dev

# 3. Build para produção
npm run build

# 4. Visualizar build
npm run preview
```

## 📁 Estrutura do projeto

```
obba-doces/
├── public/
│   └── favicon.svg
├── src/
│   ├── components/         # Componentes reutilizáveis
│   │   ├── AnimatedSection.jsx
│   │   ├── FloatingOrb.jsx
│   │   ├── StarRating.jsx
│   │   └── WhatsAppIcon.jsx
│   ├── hooks/
│   │   └── useScrollAnimation.js
│   ├── sections/           # Seções da página
│   │   ├── Navbar.jsx
│   │   ├── Hero.jsx
│   │   ├── BentoGrid.jsx
│   │   ├── WhyObba.jsx
│   │   ├── Testimonials.jsx
│   │   ├── CTA.jsx
│   │   └── Footer.jsx
│   ├── animations.js       # Variantes de animação
│   ├── constants.js        # Dados e URLs
│   ├── App.jsx
│   ├── main.jsx
│   └── index.css
├── index.html
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
├── vercel.json
└── package.json
```

## ☁️ Deploy na Vercel

1. Suba o projeto no GitHub
2. Acesse [vercel.com](https://vercel.com) e importe o repositório
3. A Vercel detecta automaticamente o Vite — clique em **Deploy**
4. Pronto! 🎉

## 📱 Contato

- WhatsApp: [wa.me/5511946408023](https://wa.me/5511946408023)
- Instagram: [@obba_docess](https://www.instagram.com/obba_docess)
